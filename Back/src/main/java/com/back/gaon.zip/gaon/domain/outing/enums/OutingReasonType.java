// com.back.gaon.domain.outing.enums.OutingReasonType
package com.back.gaon.domain.outing.enums;

public enum OutingReasonType {
    ACADEMY,  // 학원
    MEAL,     // 점심/저녁
    ETC       // 기타(편의점, 병원 등)
}