package com.back.gaon.domain.member.enums;

public enum MemberStatus {
    ACTIVE, INACTIVE, SUSPENDED //재원생,임시중단,퇴원생
}
