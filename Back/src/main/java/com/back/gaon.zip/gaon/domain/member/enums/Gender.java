package com.back.gaon.domain.member.enums;

public enum Gender {
    Male,Female
}
