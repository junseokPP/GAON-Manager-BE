package com.back.gaon.domain.member.enums;

public enum Grade {
    High1,High2,High3,REPEATER //고1,고2,고3,재수생
}
